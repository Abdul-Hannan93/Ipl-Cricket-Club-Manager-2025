package com.example.friday.Controller;

import com.example.friday.DataTransferableObject.GetPlayer;
import com.example.friday.DataTransferableObject.LoginObject;
import com.example.friday.Main;
import com.example.friday.util.SocketWrapper;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.io.IOException;

public class LoginController {
    private Main main;
    private SocketWrapper wrapper;
    private Stage stage;
    public void setStage(Stage stage) {
        this.stage=stage;
    }
    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;
    @FXML
    public void handleLogin(ActionEvent actionEvent) {
        new Thread(()->{
            String userName = usernameField.getText();
           // userName=FrequentMethods.capitalizeWord(userName);
            String password = passwordField.getText();
            LoginObject logO = new LoginObject();
            logO.setUserName(userName);
            logO.setPassword(password);
            System.out.println("4");
            try {
                main.getWrapper().write(logO);
                GetPlayer getPlayer=new GetPlayer();
                getPlayer.setName(userName);
                main.getWrapper().write(getPlayer);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();

    }

    public void init() {
    }

    public void setMain(Main main) {
        this.main=main;
    }


}
