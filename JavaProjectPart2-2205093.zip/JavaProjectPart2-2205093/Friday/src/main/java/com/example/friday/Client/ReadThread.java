
package com.example.friday.Client;

import com.example.friday.Main;
import javafx.application.Platform;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import com.example.friday.DataTransferableObject.*;
import com.example.friday.util.*;

public class ReadThread implements Runnable {
    private final Thread thr;
    private final Main main;
    public static List<Player> cl = new ArrayList<>();
    public static List<Player> ml = new ArrayList<>();

    public ReadThread(Main main) {
        this.main = main;
        this.thr = new Thread(this);
        thr.start();
    }

    @Override
    public void run() {
        try {
            while (true) {
                Object o = main.getWrapper().read();
                if (o != null) {
                    if (o instanceof LoginObject) {
                        LoginObject loginDTO = (LoginObject) o;
                        System.out.println(loginDTO.getUserName());
                        System.out.println(loginDTO.isStatus());
                        Platform.runLater(() -> {
                            if (loginDTO.isStatus()) {
                                try {
                                    main.showHomePage(loginDTO.getUserName());
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            } else {
                                main.showAlert();
                            }
                        });
                    }

                    if (o instanceof GetPlayerResponse) {
                        synchronized (ReadThread.class) {
                            new Thread(() -> {
                                GetPlayerResponse obj = (GetPlayerResponse) o;
                                cl = obj.getPlayerList();
                                ml = obj.getMarketList();
                                synchronized (Main.class) {
                                    Main.setPlayerList(cl);
                                    Main.setMarketList(ml);
                                }
                            }).start();
                        }
                    }

                    if (o instanceof SellPlayerResponse) {
                        synchronized (ReadThread.class) {
                            new Thread(() -> {
                                SellPlayerResponse obj = (SellPlayerResponse) o;
                                cl = obj.getPlayerList();
                                ml = obj.getMarketList();
                                String s = "";
                                String c = "";
                                for (Player p : cl) {
                                    s = p.getClub();
                                }
                                for (Player p : Main.getPlayerList()) {
                                    c = p.getClub();
                                }

                                List<Player> ClubMarketList = new ArrayList<>();
                                for (Player p : ml) {
                                    if (!(p.getClub().equalsIgnoreCase(c))) {
                                        ClubMarketList.add(p);
                                    }
                                }

                                if (s.equalsIgnoreCase(c)) {
                                    synchronized (Main.class) {
                                        Main.setPlayerList(cl);
                                    }
                                }
                                synchronized (Main.class) {
                                    Main.setMarketList(ClubMarketList);
                                }
                            }).start();
                        }
                    }

                    if (o instanceof BuyPlayerResponse) {
                        synchronized (ReadThread.class) {
                            new Thread(() -> {
                                BuyPlayerResponse obj = (BuyPlayerResponse) o;
                                cl = obj.getPlayerList();
                                ml = obj.getMarketList();
                                String s = "";
                                String c = "";
                                for (Player p : cl) {
                                    s = p.getClub();
                                }
                                for (Player p : Main.getPlayerList()) {
                                    c = p.getClub();
                                }

                                List<Player> ClubMarketList = new ArrayList<>();
                                for (Player p : ml) {
                                    if (!(p.getClub().equalsIgnoreCase(c))) {
                                        ClubMarketList.add(p);
                                    }
                                }

                                if (s.equalsIgnoreCase(c)) {
                                    synchronized (Main.class) {
                                        Main.setPlayerList(cl);
                                    }
                                }
                                synchronized (Main.class) {
                                    Main.setMarketList(ClubMarketList);
                                }
                            }).start();
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            try {
                main.getWrapper().closeConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}


