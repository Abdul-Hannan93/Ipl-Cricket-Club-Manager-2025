package com.example.friday.Client;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FileOperations {
    private static final String OUTPUT_FILE_NAME = "players.txt";
    public static List<Player> readFromFile() throws IOException {
        List<Player> playerList = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader("players.txt"));
            String line;
            line = br.readLine();
            while (line != null) {
                String[] token = line.split(",");
                if (token.length >= 8) {
                    String name = token[0];
                    String country = token[1];
                    int age = Integer.parseInt(token[2]);
                    double height = Double.parseDouble(token[3]);
                    String club = token[4];
                    String position = token[5];
                    int number;
                    if (!token[6].isEmpty()) {
                        number = Integer.parseInt(token[6]);
                    } else {
                        number = -1;
                    }
                    int salary = Integer.parseInt(token[7]);
                    playerList.add(new Player(name, country, age, height, club, position, number, salary));

                }
                line=br.readLine();
            }
        br.close();


        return playerList;
    }

    public static void writeToFile(List<Player> playerList) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("players.txt"))) {
            for (Player p : playerList) {
                bw.write(p.Filewrite());
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        }
    }
}

