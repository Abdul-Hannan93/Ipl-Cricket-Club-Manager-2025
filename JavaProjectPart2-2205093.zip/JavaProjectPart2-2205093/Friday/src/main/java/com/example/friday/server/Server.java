package com.example.friday.server;
import com.example.friday.Client.FileOperations;
import com.example.friday.Client.Player;
import com.example.friday.util.SocketWrapper;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
public class Server {
    private ServerSocket serverSocket;
    public HashMap<String, String> userMap;
    public static List<Player> playerList;
    public static List<Player> marketList;
    public static List<SocketWrapper> clientList;
    Server() throws Exception{
        playerList=new ArrayList<>();
        marketList=new ArrayList<>();
        clientList=new ArrayList<>();
        playerList= FileOperations.readFromFile();
        userMap = new HashMap<>();
        for(Player p:playerList){
            boolean c=false;
            for(String sr:userMap.keySet()){
                if(sr.equalsIgnoreCase(p.getClub())){
                    c=true;
                    break;
                }
            }
            if(!c){
                try (BufferedReader reader = new BufferedReader(new FileReader("password.txt"))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        String[] parts = line.split(",");
                        if (parts.length == 2) {
                            if(parts[0].equalsIgnoreCase(p.getClub()))
                            {
                                userMap.put(p.getClub(),parts[1].trim());
                            }

                        }
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        try {
            serverSocket = new ServerSocket(8888);
            while (true) {
                Socket clientSocket = serverSocket.accept();
                serve(clientSocket);
            }
        } catch (Exception e) {
            System.out.println("Server starts:" + e);
        }
    }
    public void serve(Socket clientSocket) throws IOException {
        SocketWrapper wrapper = new SocketWrapper(clientSocket);
        clientList.add(wrapper);
        new ReadThreadServer(userMap,wrapper,clientList);
    }
    public static List<Player> getPlayerList() {
        return playerList;
    }
    public static List<Player> getMarketList(){
        return marketList;
    }
    public static void setPlayerList(List<Player> playerList) {
        Server.playerList = playerList;
    }
    public static void setMarketList(List<Player> marketList) {
        Server.marketList = marketList;
    }
    public static void main(String[] args) throws Exception {
        new Server();
    }
}
