package com.example.friday.Controller;

import com.example.friday.Main;
import com.example.friday.Client.Player;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import com.example.friday.DataTransferableObject.CountryPlayerCount;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CountryPlayerController {
    Stage stage;
    String club;
    Main main;
    public List<Player> playerList=new ArrayList<>();
    public Stage getStage() {return stage;}
    public void setStage(Stage stage) {
        this.stage=stage;
    }
    public void setClub(String club)
    {
        this.club=club;
    }
    @FXML
    private TableView<CountryPlayerCount> countryPlayerTable;
    @FXML
    private TableColumn<CountryPlayerCount, String> countryCol;
    @FXML
    private TableColumn<CountryPlayerCount, Integer> playerCountCol;
    @FXML
    private Button backButton;
    @FXML
    private ObservableList<CountryPlayerCount> countryPlayerList = FXCollections.observableArrayList();

    public void handleBackButtonAction(ActionEvent actionEvent) throws Exception {
        main.showHomePage(club);

    }

    public void init(String club, List<Player> playerList) {
        this.playerList=playerList;
        this.club=club;
    }

    public void load() {
        Map<String, Integer> ret = new HashMap<>();
        for (Player p : playerList) {
            if(p.getClub().equalsIgnoreCase(club)) {
                ret.put(p.getCountry(), ret.getOrDefault(p.getCountry(), 0) + 1);
            }
        }
        countryPlayerList.clear();

        for (Map.Entry<String, Integer> entry : ret.entrySet()) {
            String country = entry.getKey();
            int playerCount = entry.getValue();
            System.out.println(country + ": " + playerCount);
            countryPlayerList.add(new CountryPlayerCount(country, playerCount));
        }

        countryPlayerTable.setItems(countryPlayerList);

        countryCol.setCellValueFactory(cellData -> cellData.getValue().countryNameProperty());
        playerCountCol.setCellValueFactory(cellData -> cellData.getValue().playerCountProperty().asObject());
    }

    public void setMain(Main main) {
        this.main=main;
    }

}
